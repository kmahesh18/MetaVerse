import { WebSocket, WebSocketServer } from "ws";

const wss = new WebSocketServer({ port: 8080 });

let senderSocket: WebSocket | null = null;
let receieverSocket: WebSocket | null = null;

console.log("server started");

wss.on("connection", function connection(ws) {
	ws.on("error", console.error);

	console.log("user connected");

	ws.on("message", function message(data: any) {
		const message = JSON.parse(data);

		console.log("got a msg");
		console.log(data, message);
		//add ice candidate

		//sender identify as sender && ssame for reciever

		if (message.type === "sender") {
			senderSocket = ws;
			console.log("sender set");
		} else if (message.type === "receiver") {
			receieverSocket = ws;
			console.log("receiver set");
		}

		// send create offer from sender to reciever ,so reciever.send()=>sends the offer to the receiver using receiver socket
		else if (message.type === "createOffer") {
			receieverSocket?.send(
				JSON.stringify({ type: "offer", offer: message.offer })
			);
			console.log("offer created");
		}
		//create answer
		else if (message.type === "createAnswer") {
			console.log("answer created");
			senderSocket?.send(
				JSON.stringify({ type: "answer", answer: message.answer })
			);
		}

		//exchange ice candidates
		else if (message.type === "iceCandidate") {
			if (ws === senderSocket) {
				receieverSocket?.send(
					JSON.stringify({ type: "iceCandidate", candidate: message.candidate })
				);
			} else if (ws === receieverSocket) {
				senderSocket?.send(
					JSON.stringify({
						type: "iceCandidate",
						candidate: message.candidate,
					})
				);
			}
		}
	});
});
