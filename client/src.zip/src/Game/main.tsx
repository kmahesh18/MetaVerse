// import { AUTO, Game } from "phaser";
// import { room1 } from "./scenes/room1";

// const StartGame = (parent: string): Game | null => {
//   if (typeof window !== "undefined") {
//     const config: Phaser.Types.Core.GameConfig = {
//       type: AUTO,
//       width: window.innerWidth,
//       height: window.innerHeight,
//       parent,
//       backgroundColor: "#028af8",
//       scene: [room1] // add your scenes here
//     };

//     return new Game(config);
//   }
//   return null;
// };

// export default StartGame;
