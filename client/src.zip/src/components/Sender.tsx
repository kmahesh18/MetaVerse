import { useEffect, useState } from "react";

export function Sender() {
  return (
    <div>
      <button>send coordindates</button>
    </div>
  );
}
